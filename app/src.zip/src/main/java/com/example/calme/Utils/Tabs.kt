package com.example.calme.Utils

enum class Tabs {
    Tasks,
    Calender,
    Weekly,
    Ss3
}