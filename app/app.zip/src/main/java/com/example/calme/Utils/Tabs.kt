package com.example.calme.Utils

enum class Tabs {
    Tasks,
    Ss1,
    Ss2,
    Ss3
}